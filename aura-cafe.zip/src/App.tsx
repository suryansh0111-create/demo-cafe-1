import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coffee, Clock, MapPin, Instagram, Menu as MenuIcon, X, ArrowRight, ChevronRight, Mail, Phone, ExternalLink } from 'lucide-react';

const MENU_DATA = {
  "Specialty Coffee": [
    { name: "Gold Leaf Espresso", price: "450", desc: "Single origin roasted beans, double shot, edible 24k gold garnish" },
    { name: "Lavender Honey Latte", price: "525", desc: "Infused with organic Provence lavender & wildflower honey" },
    { name: "Salted Cream Cold Brew", price: "475", desc: "18-hour steep, house-made sea salt foam topper" },
    { name: "Spanish Latte", price: "420", desc: "Condensed milk sweetness with balanced espresso strength" },
    { name: "Rosemary Charcoal Latte", price: "550", desc: "Activated charcoal, rosemary infusion, almond milk" },
  ],
  "Teas & Matcha": [
    { name: "Ceremonial Matcha", price: "590", desc: "Grade A Uji matcha whisked with oat silk milk" },
    { name: "Persian Rose Tea", price: "380", desc: "Dried Iranian roses, hand-plucked tea leaves" },
    { name: "Butterfly Pea Lemonade", price: "350", desc: "Color-changing botanical tea with fresh citrus" },
    { name: "Smoked Oolong", price: "440", desc: "Traditional charcoal-fired tea from Wuyi mountains" },
  ],
  "Artisanal Bakery": [
    { name: "Pistachio Croissant", price: "320", desc: "Double baked, Sicilian pistachio cream filling" },
    { name: "Charcoal Pain au Chocolat", price: "280", desc: "Valrhona 70% dark chocolate, activated charcoal dough" },
    { name: "Truffle Cheese Danish", price: "450", desc: "Flaky pastry, black truffle honey, aged gruyère" },
    { name: "Sourdough Cardamom Knot", price: "260", desc: "Stone-ground flour, organic cardamom spice" },
  ],
  "All-Day Brunch": [
    { name: "Truffle Cloud Eggs", price: "850", desc: "Whipped egg whites, yolk confit, fresh shaved truffle" },
    { name: "Saffron Salmon Tartine", price: "1200", desc: "Cold smoked salmon, saffron labneh, pickled shallots" },
    { name: "Mushroom Umami Bowl", price: "780", desc: "Wild foraged mushrooms, quinoa, miso-tahini dressing" },
    { name: "Avocado Burrata Toast", price: "950", desc: "Hass avocado, fresh burrata, heirloom tomatoes, balsamic glaze" },
    { name: "Brioche French Toast", price: "680", desc: "Thick cut brioche, vanilla bean cream, macerated berries" },
  ]
};

const PAGES = ['Home', 'Menu', 'Gallery', 'About', 'Contact'];

export default function App() {
  const [currentPage, setCurrentPage] = useState('Home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeCategory, setActiveCategory] = useState("Specialty Coffee");

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const pageVariants = {
    initial: { opacity: 0, scale: 0.98 },
    animate: { opacity: 1, scale: 1 },
    exit: { opacity: 0, scale: 1.02 }
  };

  const Nav = () => (
    <nav className={`fixed w-full z-50 transition-all duration-700 ${isScrolled ? 'glass-nav py-4' : 'bg-transparent py-8'}`}>
      <div className="max-w-7xl mx-auto px-12 flex justify-between items-center text-cafe-charcoal">
        <motion.div 
          className="cursor-pointer"
          onClick={() => setCurrentPage('Home')}
          whileHover={{ scale: 1.05 }}
        >
          <span className="text-2xl font-black tracking-tighter uppercase serif">Lumière</span>
        </motion.div>

        <div className="hidden md:flex gap-10 label-caps">
          {PAGES.map((page) => (
            <button 
              key={page} 
              onClick={() => setCurrentPage(page)}
              className={`transition-all ${currentPage === page ? 'opacity-100 text-cafe-oak underline underline-offset-8' : 'opacity-40 hover:opacity-100'}`}
            >
              {page}
            </button>
          ))}
        </div>

        <button 
          className="md:hidden text-cafe-charcoal"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X /> : <MenuIcon />}
        </button>

        <button className="hidden md:block px-6 py-2 border border-cafe-charcoal rounded-full label-caps hover:bg-cafe-charcoal hover:text-cafe-cream transition-all uppercase">
          Reservations
        </button>
      </div>
    </nav>
  );

  const Home = () => (
    <div className="pt-20">
      <section className="relative min-h-[90vh] flex items-center px-12 overflow-hidden">
        <div className="max-w-7xl mx-auto w-full grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.2 }}
          >
            <h1 className="text-[70px] md:text-[120px] bold-heading uppercase leading-[0.8] mb-8">
              A Taste Of<br />
              <span className="italic font-normal text-cafe-oak">Heaven</span><br />
              Daily.
            </h1>
            <p className="max-w-sm text-sm leading-relaxed opacity-70 font-medium mb-12">
              Lumière is an artisanal sanctuary for those who seek perfection in every sip and tranquility in every moment.
            </p>
            <button 
              onClick={() => setCurrentPage('Menu')}
              className="flex items-center gap-4 label-caps text-cafe-charcoal hover:text-cafe-oak transition-colors group"
            >
              Explore the menu <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
            </button>
          </motion.div>

          <div className="relative group">
            <motion.div 
               initial={{ opacity: 0, scale: 0.8 }}
               animate={{ opacity: 1, scale: 1 }}
               transition={{ duration: 1.5 }}
               className="aspect-[4/5] rounded-[3rem] overflow-hidden shadow-2xl relative z-10"
            >
              <img 
                src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=2047&auto=format&fit=crop" 
                className="w-full h-full object-cover transition-transform duration-[2000ms] group-hover:scale-110"
                alt="Cafe Space"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-cafe-oak/10 rounded-full blur-3xl -z-10 animate-pulse" />
          </div>
        </div>
      </section>

      {/* Featured Items */}
      <section className="py-32 px-12">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-20">
            <h2 className="text-6xl bold-heading">House <br /><span className="italic font-normal">Favorites</span></h2>
            <button onClick={() => setCurrentPage('Menu')} className="label-caps opacity-40 hover:opacity-100 flex items-center gap-2">Full Menu <ChevronRight className="w-4 h-4" /></button>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-8 rounded-[2rem] shadow-sm hover:shadow-xl transition-all"
              >
                <div className="h-64 bg-cafe-latte rounded-2xl overflow-hidden mb-6">
                  <img 
                    src={i === 1 ? "https://images.unsplash.com/photo-1541167760496-162955ed8a9f?q=80&w=1934&auto=format&fit=crop" : i === 2 ? "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1974&auto=format&fit=crop" : "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=2070&auto=format&fit=crop"}
                    className="w-full h-full object-cover"
                    alt="Product"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h3 className="text-xl font-black uppercase tracking-tight mb-2">Signature Brew 0{i}</h3>
                <p className="text-xs opacity-50 font-medium italic mb-4">Limited seasonal batch sourced from high-altitude Ethiopian estates.</p>
                <span className="text-cafe-oak font-serif text-lg">₹450</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );

  const Menu = () => (
    <div className="pt-40 px-12 pb-32">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-20 md:mb-24">
          <span className="label-caps text-cafe-oak mb-4 block">The Full Collection</span>
          <h1 className="text-7xl md:text-9xl bold-heading uppercase">Menu</h1>
        </div>

        <div className="flex overflow-x-auto gap-8 md:gap-12 border-b border-cafe-latte pb-4 mb-20 no-scrollbar">
          {Object.keys(MENU_DATA).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`label-caps whitespace-nowrap transition-all relative pb-4 md:pb-6 ${activeCategory === cat ? 'text-cafe-charcoal opacity-100' : 'opacity-30 hover:opacity-100'}`}
            >
              {cat}
              {activeCategory === cat && (
                <motion.div layoutId="underline" className="absolute bottom-0 left-0 right-0 h-[2px] bg-cafe-charcoal" />
              )}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-x-20 gap-y-16">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="contents"
            >
              {MENU_DATA[activeCategory as keyof typeof MENU_DATA].map((item, idx) => (
                <div key={idx} className="group border-b border-cafe-latte pb-10">
                  <div className="flex justify-between items-baseline mb-4">
                    <h3 className="text-2xl font-black uppercase tracking-tighter group-hover:text-cafe-oak transition-colors">{item.name}</h3>
                    <span className="font-serif text-2xl font-light">₹{item.price}</span>
                  </div>
                  <p className="text-sm leading-relaxed opacity-50 font-medium italic">{item.desc}</p>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );

  const Gallery = () => (
    <div className="pt-40 px-12 pb-32">
      <div className="max-w-7xl mx-auto">
        <div className="mb-24">
          <h1 className="text-8xl bold-heading uppercase">Space <br /><span className="italic font-normal">Philosophy</span></h1>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            "https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=2047&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=2070&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1974&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1541167760496-162955ed8a9f?q=80&w=1934&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1974&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=2070&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1974&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?q=80&w=2071&auto=format&fit=crop"
          ].map((url, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className={`rounded-3xl overflow-hidden shadow-lg aspect-square ${i === 2 || i === 5 ? 'md:col-span-2' : ''}`}
            >
              <img src={url} className="w-full h-full object-cover hover:scale-105 transition-transform duration-1000" alt="Gallery" referrerPolicy="no-referrer" />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );

  const About = () => (
    <div className="pt-40 px-12 pb-32">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-8xl bold-heading uppercase mb-12">Our <br /><span className="italic font-normal">Aura</span></h1>
        <div className="flex flex-col gap-12 font-medium text-xl leading-relaxed text-cafe-charcoal/80">
          <p>Founded in 2024, Lumière was born from a singular obsession: the architecture of taste. We believe that the space you inhabit while drinking your morning coffee is just as important as the roast itself.</p>
          <img src="https://images.unsplash.com/photo-1600100414328-98e94553229b?q=80&w=2070&auto=format&fit=crop" className="w-full h-[600px] object-cover rounded-[4rem] my-10" alt="Founder" referrerPolicy="no-referrer" />
          <p>Our beans are selected through a rigorous process of direct trade, ensuring that the farmers who labor over the soil receive the respect and compensation they deserve.</p>
        </div>
      </div>
    </div>
  );

  const Contact = () => (
    <div className="pt-40 px-12 pb-32">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-32 items-center">
        <div>
          <h1 className="text-8xl bold-heading uppercase mb-12">Reach <br /><span className="italic font-normal">Out</span></h1>
          <div className="space-y-12">
            <div className="flex gap-6 items-center group">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <Mail className="text-cafe-oak" />
              </div>
              <div>
                <span className="label-caps opacity-40 text-[9px]">Email</span>
                <p className="text-2xl font-serif italic">hello@lumiere.cafe</p>
              </div>
            </div>
            <div className="flex gap-6 items-center group">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <Phone className="text-cafe-oak" />
              </div>
              <div>
                <span className="label-caps opacity-40 text-[9px]">Call</span>
                <p className="text-2xl font-serif italic">+91 98765 43210</p>
              </div>
            </div>
            <div className="flex gap-6 items-center group">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <MapPin className="text-cafe-oak" />
              </div>
              <div>
                <span className="label-caps opacity-40 text-[9px]">Flagship</span>
                <p className="text-2xl font-serif italic">Bandra West, Mumbai</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-10 md:p-14 rounded-[50px] shadow-2xl">
          <h2 className="text-4xl bold-heading mb-10 uppercase">Message</h2>
          <form className="space-y-10" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-2">
              <label className="label-caps text-[9px] opacity-40">Your Name</label>
              <input type="text" className="w-full border-b border-cafe-latte pb-4 focus:outline-none focus:border-cafe-oak transition-colors text-lg italic font-serif bg-transparent" />
            </div>
            <div className="space-y-2">
              <label className="label-caps text-[9px] opacity-40">Email Address</label>
              <input type="email" className="w-full border-b border-cafe-latte pb-4 focus:outline-none focus:border-cafe-oak transition-colors text-lg italic font-serif bg-transparent" />
            </div>
            <div className="space-y-2">
              <label className="label-caps text-[9px] opacity-40">Message</label>
              <textarea rows={3} className="w-full border-b border-cafe-latte pb-4 focus:outline-none focus:border-cafe-oak transition-colors text-lg italic font-serif bg-transparent" />
            </div>
            <button className="w-full bg-cafe-charcoal text-cafe-cream py-6 rounded-full label-caps hover:scale-[1.02] active:scale-[0.98] transition-transform uppercase font-black">Send Signal</button>
          </form>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-cafe-cream min-h-screen selection:bg-cafe-oak/30 font-sans text-cafe-charcoal">
      <Nav />
      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-cafe-cream flex flex-col p-12"
          >
            <button className="self-end mb-20 p-2" onClick={() => setIsMenuOpen(false)}>
              <X className="w-10 h-10" />
            </button>
            <div className="flex flex-col gap-10">
              {PAGES.map((page) => (
                <button 
                  key={page} 
                  onClick={() => { setCurrentPage(page); setIsMenuOpen(false); }}
                  className="text-6xl bold-heading uppercase text-left group"
                >
                  <span className={`${currentPage === page ? 'text-cafe-oak italic' : 'opacity-40'}`}>{page}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        <motion.main
          key={currentPage}
          initial="initial"
          animate="animate"
          exit="exit"
          variants={pageVariants}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          {currentPage === 'Home' && <Home />}
          {currentPage === 'Menu' && <Menu />}
          {currentPage === 'Gallery' && <Gallery />}
          {currentPage === 'About' && <About />}
          {currentPage === 'Contact' && <Contact />}
        </motion.main>
      </AnimatePresence>

      <footer className="py-32 bg-cafe-charcoal text-cafe-cream px-12 mt-20">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-20">
          <div className="col-span-2">
            <span className="text-4xl font-black serif uppercase tracking-tighter block mb-8">Lumière</span>
            <p className="text-cafe-cream/40 max-w-sm leading-relaxed font-medium text-sm">
              We reside at the intersection of traditional craft and modern minimalism. A dialogue between the earth and the cup.
            </p>
          </div>
          <div>
            <h4 className="label-caps mb-8 text-cafe-oak">Explore</h4>
            <div className="flex flex-col gap-4 label-caps text-[10px] opacity-50">
              {PAGES.map(p => <button key={p} onClick={() => setCurrentPage(p)} className="text-left hover:opacity-100 transition-opacity">{p}</button>)}
            </div>
          </div>
          <div>
            <h4 className="label-caps mb-8 text-cafe-oak">Social</h4>
            <div className="flex flex-col gap-4 label-caps text-[10px] opacity-50 font-bold">
              <span className="hover:opacity-100 cursor-pointer underline italic">Instagram</span>
              <span className="hover:opacity-100 cursor-pointer underline italic">Behance</span>
              <span className="hover:opacity-100 cursor-pointer underline italic">Journal</span>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-32 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between gap-4 label-caps opacity-20 text-[9px]">
          <span>© 2026 Lumière Collective</span>
          <span>Mumbai • Bangalore • New Delhi</span>
        </div>
      </footer>
    </div>
  );
}

